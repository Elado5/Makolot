module.exports = {
    db: {
        user: `db_a779d2_proj4_admin`,
        password: `8CcJK8jQmG9JUfXs`,
        server: `sql5105.site4now.net`,
        database: `db_a779d2_proj4`,
        options: {
            enableArithAbort: true, //this ends a query when an overflow or divide-by-zero error occurs during query execution.
            trustServerCertificate: true,
        }
    }
}